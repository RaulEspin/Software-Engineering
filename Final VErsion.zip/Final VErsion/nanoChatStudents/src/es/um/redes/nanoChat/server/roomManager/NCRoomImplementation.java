package es.um.redes.nanoChat.server.roomManager;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import es.um.redes.nanoChat.messageFV.NCMessage;
import es.um.redes.nanoChat.messageFV.NCRoomMessage;

public class NCRoomImplementation extends NCRoomManager {
	HashMap<String, Socket> usuariosSala = new HashMap<String, Socket>();
	public long timeLastMessage;
	
	@Override
	public boolean registerUser(String u, Socket s) {
		
		if( usuariosSala.containsKey(u) )
			
			return false;
		else{
			usuariosSala.put(u, s);
			return true;
		}
	}

	@Override
	public void broadcastMessage(String u, String message) throws IOException {
		 DataOutputStream dos;
		 for( String usu : usuariosSala.keySet() ){
			 if(u.equals(usu)){
				 continue;
			 }
			 Socket s = usuariosSala.get(usu);
			 dos =  new DataOutputStream(s.getOutputStream());
			 NCRoomMessage msg = (NCRoomMessage) NCMessage.makeRoomMessage(NCMessage.OP_MENSAJE, message);
			 dos.writeUTF(msg.toEncodedString());
		 }
		Date fecha = new Date();
		timeLastMessage = fecha.getTime();
	}

	@Override
	public void removeUser(String u) {
		usuariosSala.remove(u);
		
	}

	@Override
	public void setRoomName(String roomName) {
		this.roomName = roomName;
		
	}

	@Override
	public NCRoomDescription getDescription() {
		ArrayList<String> members= new ArrayList<String>();
		members.addAll(usuariosSala.keySet());
		NCRoomDescription ncRD = new NCRoomDescription(roomName,members, timeLastMessage); 
		return ncRD;
	}

	@Override
	public int usersInRoom() {
		
		return usuariosSala.size();
	}

}
