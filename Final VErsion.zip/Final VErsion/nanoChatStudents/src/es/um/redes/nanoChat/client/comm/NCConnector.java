package es.um.redes.nanoChat.client.comm;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import es.um.redes.nanoChat.messageFV.NCInfoRoomMessage;
import es.um.redes.nanoChat.messageFV.NCListRoomsMessage;
import es.um.redes.nanoChat.messageFV.NCMessage;
import es.um.redes.nanoChat.messageFV.NCOpCodeMessage;
import es.um.redes.nanoChat.messageFV.NCRoomMessage;
import es.um.redes.nanoChat.server.roomManager.NCRoomDescription;

//Esta clase proporciona la funcionalidad necesaria para intercambiar mensajes entre el cliente y el servidor de NanoChat
public class NCConnector {
	private Socket socket;
	protected DataOutputStream dos;
	protected DataInputStream dis;
	
	public NCConnector(InetSocketAddress serverAddress) throws UnknownHostException, IOException {
		// Se crea el socket a partir de la dirección proporcionada 
		socket = new Socket(serverAddress.getAddress() , serverAddress.getPort());
		
		// Se extraen los streams de entrada y salida
		dos =  new DataOutputStream(socket.getOutputStream());
		dis = new DataInputStream(socket.getInputStream());
	}



	
	//Método para registrar el nick en el servidor. Nos informa sobre si la inscripción se hizo con éxito o no.
	public boolean registerNickname(String nick) throws IOException {
		//Funcionamiento resumido: SEND(nick) and RCV(NICK_OK) or RCV(NICK_DUPLICATED)
		//Creamos un mensaje de tipo RoomMessage con opcode OP_NICK en el que se inserte el nick
		NCRoomMessage message = (NCRoomMessage) NCMessage.makeRoomMessage(NCMessage.OP_NICK, nick);
		//Obtenemos el mensaje de texto listo para enviar
		String rawMessage = message.toEncodedString();
		//Escribimos el mensaje en el flujo de salida, es decir, provocamos que se envíe por la conexión TCP
		dos.writeUTF(rawMessage);
		// Leemos el mensaje recibido como respuesta por el flujo de entrada 
		String respuesta = dis.readUTF(); 
		
		// Analizamos el mensaje para saber si está duplicado el nick (modificar el return en consecuencia)
		if ( respuesta.equals("NICK_OK")) {
			return true;
		}
		return false;
	}
	
	//Método para obtener la lista de salas del servidor
	public ArrayList<NCRoomDescription> getRooms() throws IOException {
		//Funcionamiento resumido: SND(GET_ROOMS) and RCV(ROOM_LIST)
		NCOpCodeMessage mensaje = (NCOpCodeMessage) NCMessage.makeOpCodeMessage(NCMessage.OP_LIST_REQUEST);
		dos.writeUTF(mensaje.toEncodedString());
		String mesg = dis.readUTF();
	
		NCListRoomsMessage mensaje2;
		mensaje2 = NCListRoomsMessage.readFromString(NCMessage.OP_LIST_ROOM, mesg);
		return mensaje2.getRooms();
	}
	
	//Método para solicitar la entrada en una sala
	public boolean enterRoom(String room) throws IOException {
		//Funcionamiento resumido: SND(ENTER_ROOM<room>) and RCV(IN_ROOM) or RCV(REJECT)
		NCRoomMessage mensaje = (NCRoomMessage) NCMessage.makeRoomMessage(NCMessage.OP_ENTER_ROOM,room);
		dos.writeUTF(mensaje.toEncodedString());
		NCOpCodeMessage msj = (NCOpCodeMessage) NCMessage.readMessageFromSocket(dis);
		if ( msj.getOpcode() == NCMessage.OP_OK  ){
			return true;
		}
		
		return false;
	}
	
	//Método para salir de una sala
	public void leaveRoom(String room) throws IOException {
		//Funcionamiento resumido: SND(EXIT_ROOM)
		NCOpCodeMessage mensaje = (NCOpCodeMessage) NCMessage.makeOpCodeMessage(NCMessage.OP_EXIT_ROOM);
		dos.writeUTF(mensaje.toEncodedString());
		
	}
	
	//Método que utiliza el Shell para ver si hay datos en el flujo de entrada
	public boolean isDataAvailable() throws IOException {
		return (dis.available() != 0);
	}
	
	//IMPORTANTE!!
	//TODO Es necesario implementar métodos para recibir y enviar mensajes de chat a una sala
	public void sendMensaje(String mensaje) throws IOException{
		NCRoomMessage message = (NCRoomMessage) NCMessage.makeRoomMessage(NCMessage.OP_MENSAJE, mensaje);
		//Obtenemos el mensaje de texto listo para enviar
		String msj = message.toEncodedString();
		//Escribimos el mensaje en el flujo de salida, es decir, provocamos que se envíe por la conexión TCP
		dos.writeUTF(msj);
	}
	
	public NCMessage recibirMensaje() throws IOException{
		return NCMessage.readMessageFromSocket(dis);
		
	}

	//Método para pedir la descripción de una sala
	public NCRoomDescription getRoomInfo(String room) throws IOException {
		//Funcionamiento resumido: SND(GET_ROOMINFO) and RCV(ROOMINFO)
		// Construimos el mensaje de solicitud de información de la sala específica
		NCOpCodeMessage mensaje = (NCOpCodeMessage) NCMessage.makeOpCodeMessage(NCMessage.OP_INFO_REQUEST);
		dos.writeUTF(mensaje.toEncodedString());
		
		// Recibimos el mensaje de respuesta
		NCInfoRoomMessage msg = (NCInfoRoomMessage) NCMessage.readMessageFromSocket(dis);
		
		
		//Devolvemos la descripción contenida en el mensaje
		return msg.getInfoRoom();
		
	}
	
	//Método para cerrar la comunicación con la sala
	//TODO (Opcional) Enviar un mensaje de salida del servidor de Chat
	public void disconnect() {
		try {
			if (socket != null) {
				socket.close();
			}
		} catch (IOException e) {
		} finally {
			socket = null;
		}
	}


}
