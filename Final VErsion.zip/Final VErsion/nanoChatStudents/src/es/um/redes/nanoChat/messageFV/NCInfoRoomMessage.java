package es.um.redes.nanoChat.messageFV;

import java.util.ArrayList;

import es.um.redes.nanoChat.server.roomManager.NCRoomDescription;

public class NCInfoRoomMessage extends NCMessage {

	private NCRoomDescription infoRoom;

	static private final String ROOM_FIELD = "RoomName";

	static private final String MEMBERS_FIELD = "Members";

	static private final String LASTMSG_FIELD = "Last message";

	public NCInfoRoomMessage(byte type, NCRoomDescription info) {

		this.opcode = type;

		this.infoRoom = info;

	}

	public String toEncodedString() {

		StringBuffer sb = new StringBuffer();
		sb.append(OPCODE_FIELD + DELIMITER + opcodeToOperation(opcode) + END_LINE); // Construimos el campo
		sb.append(ROOM_FIELD + DELIMITER + infoRoom.roomName + END_LINE);
		sb.append(MEMBERS_FIELD + DELIMITER + " " + infoRoom.members.toString() + END_LINE);
		sb.append(LASTMSG_FIELD + DELIMITER + infoRoom.timeLastMessage + END_LINE); // Construimos el campo
		sb.append(END_LINE); // Marcamos el final del mensaje
		return sb.toString(); // Se obtiene el mensaje

	}

	// Parseamos
	public static NCInfoRoomMessage readFromString(byte code, String message) {
		String[] campos = message.split(END_LINE + "");
		NCRoomDescription info = null;

		int idx = campos[1].indexOf(DELIMITER); // Posici�n del delimitador

		String nombreSala = campos[1].substring(idx + 1).trim();

		idx = campos[2].indexOf(DELIMITER);

		String miembros = campos[2].substring(idx + 1).trim();

		String[] miembros2 = miembros.split(",");

		ArrayList<String> members = new ArrayList<String>();

		for (String m : miembros2) {

			members.add(m);

		}

		idx = campos[3].indexOf(DELIMITER);

		String time = campos[3].substring(idx + 1).trim();

		long timelapse = Long.parseLong(time);

		info = new NCRoomDescription(nombreSala, members, timelapse);

		return new NCInfoRoomMessage(code, info);

	}

	public NCRoomDescription getInfoRoom() {

		return infoRoom;

	}







}