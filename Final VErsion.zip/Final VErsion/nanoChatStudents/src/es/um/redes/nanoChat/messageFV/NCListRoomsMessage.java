package es.um.redes.nanoChat.messageFV;

import java.util.ArrayList;

import es.um.redes.nanoChat.server.roomManager.NCRoomDescription;

public class NCListRoomsMessage extends NCMessage {

	private ArrayList<NCRoomDescription> rooms;
	static private final String LIST_ROOM = "List Room";
	static private final String MEMBERS_FIELD = "Members";
	static private final String LASTMSG_FIELD = "Last message";

	public NCListRoomsMessage(byte type, ArrayList<NCRoomDescription> array) {
		this.opcode = type;
		this.rooms = new ArrayList<NCRoomDescription>(array);
	}

	@Override
	public String toEncodedString() {
		StringBuffer sb = new StringBuffer();
		sb.append(OPCODE_FIELD + DELIMITER + opcodeToOperation(opcode) + END_LINE);

		sb.append(LIST_ROOM + DELIMITER);
		for (NCRoomDescription s : rooms)
			sb.append("#" + s.getRoomName());
		sb.append(END_LINE);

		sb.append(MEMBERS_FIELD + DELIMITER);
		for (NCRoomDescription s : rooms)
			sb.append("#" + " " + s.getMembers().toString());
		sb.append(END_LINE);

		sb.append(LASTMSG_FIELD + DELIMITER);
		for (NCRoomDescription s : rooms)
			sb.append("#" + s.getTimeLastMessage());

		sb.append("#" + END_LINE + END_LINE);
		return sb.toString();
	}

	public static NCListRoomsMessage readFromString(byte code, String message) {

		ArrayList<NCRoomDescription> array = new ArrayList<NCRoomDescription>();

		String[] campos = message.split(END_LINE + "");

		int idx = campos[1].indexOf(DELIMITER); // Posición del delimitador
		String[] nombresSalas = campos[1].substring(idx + 1).trim().split("#");

		idx = campos[2].indexOf(DELIMITER);
		String[] miembrosSala = campos[2].substring(idx + 1).split("#");

		ArrayList<ArrayList<String>> members = new ArrayList<ArrayList<String>>();

		for (String s : miembrosSala) {
			ArrayList<String> nombresSala = new ArrayList<String>();
			String[] nombres = s.split(" ");
			for (String n : nombres) {
				if (!(n.equals("") || n.equals("[]"))) {
					nombresSala.add(n);

				}
			}
			members.add(nombresSala);
		}

		idx = campos[3].indexOf(DELIMITER);
		String[] times = campos[3].substring(idx + 1).trim().split("#");

		for (int i = 1; i < nombresSalas.length; i++) {
			array.add(new NCRoomDescription(nombresSalas[i], members.get(i), Long.parseLong(times[i])));
		}

		return new NCListRoomsMessage(code, array);
	}

	public ArrayList<NCRoomDescription> getRooms() {
		return new ArrayList<NCRoomDescription>(rooms);
	}

}
