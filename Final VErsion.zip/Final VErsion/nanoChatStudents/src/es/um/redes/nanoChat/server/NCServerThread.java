package es.um.redes.nanoChat.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;


import es.um.redes.nanoChat.messageFV.NCInfoRoomMessage;
import es.um.redes.nanoChat.messageFV.NCListRoomsMessage;
import es.um.redes.nanoChat.messageFV.NCMessage;
import es.um.redes.nanoChat.messageFV.NCOpCodeMessage;
import es.um.redes.nanoChat.messageFV.NCRoomMessage;
import es.um.redes.nanoChat.server.roomManager.NCRoomDescription;
import es.um.redes.nanoChat.server.roomManager.NCRoomManager;

/**
 * A new thread runs for each connected client
 */
public class NCServerThread extends Thread {
	
	
	private Socket socket = null;
	//Manager global compartido entre los Threads
	private NCServerManager serverManager = null;
	//Input and Output Streams
	private DataInputStream dis;
	private DataOutputStream dos;
	//Usuario actual al que atiende este Thread
	String user;
	//RoomManager actual (dependerá de la sala a la que entre el usuario)
	NCRoomManager roomManager;
	//Sala actual
	String currentRoom;

	//Inicialización de la sala
	public NCServerThread(NCServerManager manager, Socket socket) throws IOException {
		super("NCServerThread");
		this.socket = socket;
		this.serverManager = manager;
	}

	//Main loop
	public void run() {
		try {
			//Se obtienen los streams a partir del Socket
			dis = new DataInputStream(socket.getInputStream());
			dos = new DataOutputStream(socket.getOutputStream());
			//En primer lugar hay que recibir y verificar el nick
			receiveAndVerifyNickname();
			//Mientras que la conexión esté activa entonces...
			while (true) {
				// Obtenemos el mensaje que llega y analizamos su código de operación
				NCMessage message = NCMessage.readMessageFromSocket(dis);
				switch (message.getOpcode()) {
				// 1) si se nos pide la lista de salas se envía llamando a sendRoomList();
				case NCMessage.OP_LIST_REQUEST:
					sendRoomList();
					break;
					
				
				case NCMessage.OP_ENTER_ROOM:
				// 2) Si se nos pide entrar en la sala entonces obtenemos el RoomManager de la sala,
					NCRoomMessage msj = (NCRoomMessage) message;
					NCRoomManager sala = serverManager.enterRoom(user, msj.getName(), socket);
					roomManager = sala;
				// 2) notificamos al usuario que ha sido aceptado y procesamos mensajes con processRoomMessages()
					if(sala != null){
						
						NCOpCodeMessage mensaje = (NCOpCodeMessage) NCMessage.makeOpCodeMessage(NCMessage.OP_OK);
						currentRoom= msj.getName();
						dos.writeUTF(mensaje.toEncodedString());
						processRoomMessages();
					} else{
						//2) Si el usuario no es aceptado en la sala entonces se le notifica al cliente
						NCOpCodeMessage mensaje = (NCOpCodeMessage) NCMessage.makeOpCodeMessage(NCMessage.OP_FAIL);
						dos.writeUTF(mensaje.toEncodedString());
					}
				
					break;
				}
			}
		} catch (Exception e) {
			//If an error occurs with the communications the user is removed from all the managers and the connection is closed
			System.out.println("* User "+ user + " disconnected.");
			serverManager.leaveRoom(user, currentRoom);
			serverManager.removeUser(user);
		}
		finally {
			if (!socket.isClosed())
				try {
					socket.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
		}
	}

	//Obtenemos el nick y solicitamos al ServerManager que verifique si está duplicado
	private void receiveAndVerifyNickname() {
		//La lógica de nuestro programa nos obliga a que haya un nick registrado antes de proseguir
		// Entramos en un bucle hasta comprobar que alguno de los nicks proporcionados no está duplicado
		while(true) {
			// Extraer el nick del mensaje
			NCMessage mesg = null;
			try {
				mesg = NCMessage.readMessageFromSocket(dis);
				if (mesg.getOpcode() != NCMessage.OP_NICK) {
					NCOpCodeMessage mesgErr = (NCOpCodeMessage) NCMessage.makeOpCodeMessage(NCMessage.OP_FAIL);
					dos.writeUTF(mesgErr.toEncodedString());				
					
				} else {
					NCRoomMessage msgNick = (NCRoomMessage) mesg; 
					// Validar el nick utilizando el ServerManager - addUser()
					// Contestar al cliente con el resultado (éxito o duplicado)
					if(serverManager.addUser(msgNick.getName())) {
						
						try {
							user=msgNick.getName();
							dos.writeUTF("NICK_OK");
							break;
						} catch (IOException e) {
							//  Auto-generated catch block
							e.printStackTrace();
						}
					
					} else {
						try {
							dos.writeUTF("DUPLICATED");
						} catch (IOException e) {
							//  Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
				// cadena = dis.readUTF();
			} catch (IOException e) {
				//  Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		}
		
		
		
	}

	//Mandamos al cliente la lista de salas existentes
	private void sendRoomList()  {
		// La lista de salas debe obtenerse a partir del RoomManager y después enviarse mediante su mensaje correspondiente
		ArrayList<NCRoomDescription> salas = serverManager.getRoomList();
		NCListRoomsMessage mensaje = (NCListRoomsMessage) NCMessage.makeListRoomsMessage(NCMessage.OP_LIST_ROOM, salas);
		try {
			dos.writeUTF(mensaje.toEncodedString());
		} catch (IOException e) {
			System.out.println("Fallo en el listado de salas");
		}
	}

	private void processRoomMessages()  {
		// Comprobamos los mensajes que llegan hasta que el usuario decida salir de la sala	
		boolean exit = false;
		while (!exit) {
			NCMessage message = null;
			try {
				message = NCMessage.readMessageFromSocket(dis);
			} catch (IOException e) {
				// TODO Bloque catch generado autom�ticamente
				e.printStackTrace();
			}
			//Se recibe el mensaje enviado por el usuario
			//Se analiza el código de operación del mensaje y se trata en consecuencia
			switch (message.getOpcode()) {
			
				case NCMessage.OP_INFO_REQUEST:{
						
						NCInfoRoomMessage msj = (NCInfoRoomMessage) NCMessage.makeInfoRoomMessage(NCMessage.OP_INFO_ROOM,serverManager.getInfoRoom(currentRoom) );
						try {
							dos.writeUTF(msj.toEncodedString());
						} catch (IOException e) {
							System.out.println("No se pudo pedir la informaci�n de la sala");
						}
						break;
				}
				case NCMessage.OP_EXIT_ROOM:{
					serverManager.leaveRoom(user, currentRoom);
					exit = true;
					break;
				}
				case NCMessage.OP_MENSAJE:{
					NCRoomMessage mensaje = (NCRoomMessage) message;
					try {
						
						roomManager.broadcastMessage(user, user + ": " + mensaje.getName());
					} catch (IOException e) {
						System.out.println("No se pudo enviar los mensajes");
					}
					break;
				}
			}
			
		}
	}
}
