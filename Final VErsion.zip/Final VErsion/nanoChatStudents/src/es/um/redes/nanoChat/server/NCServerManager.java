package es.um.redes.nanoChat.server;

import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;


import es.um.redes.nanoChat.server.roomManager.NCRoomDescription;
import es.um.redes.nanoChat.server.roomManager.NCRoomImplementation;
import es.um.redes.nanoChat.server.roomManager.NCRoomManager;

/**
 * Esta clase contiene el estado general del servidor (sin la lógica relacionada con cada sala particular)
 */
class NCServerManager {
	
	//Primera habitación del servidor
	final static byte INITIAL_ROOM = 'A';
	final static String ROOM_PREFIX = "Room";
	//Siguiente habitación que se creará
	byte nextRoom;
	//Usuarios registrados en el servidor
	private HashSet<String> users = new HashSet<String>();
	//Habitaciones actuales asociadas a sus correspondientes RoomManagers
	private HashMap<String,NCRoomManager> rooms = new HashMap<String,NCRoomManager>();
	
	NCServerManager() {
		nextRoom = INITIAL_ROOM;
		NCRoomImplementation sala = new NCRoomImplementation();
		registerRoomManager(sala);
		
		nextRoom = 'B';
		sala = new NCRoomImplementation();
		registerRoomManager(sala);
	}
	
	//Método para registrar un RoomManager 
	public void registerRoomManager(NCRoomManager rm) {
		//TODO Dar soporte para que pueda haber más de una sala en el servidor
		String roomName = ROOM_PREFIX + (char) nextRoom; 
		rooms.put(roomName, rm);
		rm.setRoomName(roomName);
	}
	
	//Devuelve la descripción de las salas existentes
	public synchronized ArrayList<NCRoomDescription> getRoomList() {
		 ArrayList<NCRoomDescription> salas = new ArrayList<NCRoomDescription>();
		// Pregunta a cada RoomManager cuál es la descripción actual de su sala
		for ( String s : rooms.keySet() ){
			// Añade la información al ArrayList
			salas.add( rooms.get(s).getDescription() );
		}
		
		return salas;
	}
	
	
	//Intenta registrar al usuario en el servidor.
	public synchronized boolean addUser(String user) {
		// Devuelve true si no hay otro usuario con su nombre
		// Devuelve false si ya hay un usuario con su nombre
		return users.add(user);
	}
	
	//Elimina al usuario del servidor
	public synchronized void removeUser(String user) {
		// Elimina al usuario del servidor
		users.remove(user);
	}
	
	//Un usuario solicita acceso para entrar a una sala y registrar su conexión en ella
	public synchronized NCRoomManager enterRoom(String u, String room, Socket s) {
		// Verificamos si la sala existe
		
		
		if ( !rooms.containsKey(room) ){
			// Decidimos qué hacer si la sala no existe (devolver error O crear la sala)
			
			return null;
		}
		
		// Si la sala existe y si es aceptado en la sala entonces devolvemos el RoomManager de la sala
		NCRoomImplementation sala = (NCRoomImplementation) rooms.get(room);
		sala.registerUser(u, s);
		return sala;
	}
	
	//Un usuario deja la sala en la que estaba 
	public synchronized void leaveRoom(String u, String room) {
		
		// Verificamos si la sala existe
			
			if ( rooms.containsKey(room) ){
				// Si la sala existe sacamos al usuario de la sala
				NCRoomImplementation sala = (NCRoomImplementation) rooms.get(room);
				sala.removeUser(u);
			}
		
		// Decidir qué hacer si la sala se queda vacía
		//Nada
			
	}
	
	public synchronized NCRoomDescription getInfoRoom(String room) {
		 return rooms.get(room).getDescription();
	}

}
