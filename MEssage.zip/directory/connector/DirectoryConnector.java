package es.um.redes.nanoChat.directory.connector;


import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;


/**
 * Cliente con métodos de consulta y actualización específicos del directorio
 */
public class DirectoryConnector {
	// Tamaño máximo del paquete UDP (los mensajes intercambiados son muy
	// cortos)
	private static final int PACKET_MAX_SIZE = 128;
	// Puerto en el que atienden los servidores de directorio
	private static final int DEFAULT_PORT = 6868;
	// Valor del TIMEOUT
	private static final int TIMEOUT = 1000;
	
	public static final int protocolo = 103;

	private static final byte OP_CODE_REQUEST = 0;
	private static final byte OP_CODE_REGISTER = 1;
	private static final byte OP_CODE_REGISTER_OK = 2;
	private static final byte OP_CODE_RESPONSE = 4;

	private DatagramSocket socket; // socket UDP
	private InetSocketAddress directoryAddress; // dirección del servidor de
												// directorio

	public DirectoryConnector(String agentAddress) throws IOException {
		// A partir de la dirección y del puerto generar la dirección de
		// conexión para el Socket

		directoryAddress = new InetSocketAddress(InetAddress.getByName(agentAddress), DEFAULT_PORT);

		// Crear el socket UDP
		socket = new DatagramSocket();
	}

	/**
	 * Envía una solicitud para obtener el servidor de chat asociado a un
	 * determinado protocolo
	 * 
	 */
	public InetSocketAddress getServerForProtocol(int protocol) throws IOException {

		// Generar el mensaje de consulta llamando a buildQuery()
		byte[] request = buildQuery(protocol);

		// Construir el datagrama con la consulta
		DatagramPacket pckt = new DatagramPacket(request, request.length, directoryAddress);
		int numIntentos = 0;
		while (numIntentos < 3) {
			// Enviar datagrama por el socket
			socket.send(pckt);

			// preparar el buffer para la respuesta

			byte[] response = new byte[PACKET_MAX_SIZE];
			pckt = new DatagramPacket(response, response.length);
			// Establecer el temporizador para el caso en que no haya respuesta
			socket.setSoTimeout(TIMEOUT);
			// Recibir la respuesta
			try {
				socket.receive(pckt);
				break;
			} catch (IOException e) {
				numIntentos++;
				System.out.println("TIMEOUT");
			}
		}
		
		if (numIntentos == 3) {
			System.out.println("NO SE HA PODIDO CONSEGUIR EL SERVER CON EL PROTOCOLO");
			return null;
		}
		// Procesamos la respuesta para devolver la dirección que hay en ella
		InetSocketAddress ca = getAddressFromResponse(pckt);
		return ca;

	}


	// Método para generar el mensaje de consulta (para obtener el servidor
	// asociado a un protocolo)
	private byte[] buildQuery(int protocol) {
		// Devolvemos el mensaje codificado en binario según el formato
		// acordado
		ByteBuffer bb = ByteBuffer.allocate(5);
		bb.put(OP_CODE_REQUEST);
		bb.putInt(protocol);
		byte[] men = bb.array();
		return men;
	}

	// Método para obtener la dirección de internet a partir del mensaje UDP
	// de respuesta
	private InetSocketAddress getAddressFromResponse(DatagramPacket packet) throws UnknownHostException {
		// Analizar si la respuesta no contiene dirección (devolver null)
		/*InetAddress ip = packet.getAddress();
		if (ip == null) {
			return null;
		}*/
		byte[] bb = packet.getData();
		ByteBuffer ret = ByteBuffer.wrap(bb); //Toma como entrada men
		byte opcode = ret.get(); 
		
		// Si la respuesta no está vacía, devolver la dirección (extraerla
		// del mensaje)
		 if (opcode == OP_CODE_RESPONSE) {
			byte[] dst = new byte[4];
			ret.get(dst);
			int puerto = ret.getInt();
			InetAddress ca = InetAddress.getByAddress(dst);
			return new InetSocketAddress(ca, puerto);
		} 
		
		return null;

	}

	/**
	 * Envía una solicitud para registrar el servidor de chat asociado a un
	 * determinado protocolo
	 * 
	 */
	public boolean registerServerForProtocol(int protocol, int port) throws IOException {
		// ejercicio 3 del boletin 3
		// Construir solicitud de registro (buildRegistration) metodo de abajo
		byte[] regis = buildRegistration(protocol, port);

		// Enviar solicitud
		DatagramPacket pckt = new DatagramPacket(regis, regis.length, directoryAddress);
		int numIntentos = 0;
		DatagramPacket pckt2 = new DatagramPacket(regis, regis.length);
		while (numIntentos < 3) {
			socket.setSoTimeout(TIMEOUT);
			socket.send(pckt);

			
			// Recibe respuesta
			try {
				socket.receive(pckt2);
				break;
			} catch (IOException e) {
				System.out.println("TIMEOUT");
				numIntentos++;
			}
		}
		// Procesamos la respuesta para ver si se ha podido registrar
		// correctamente
	
		if ( numIntentos == 3 ){
			System.out.println( "NO SE HA PODIDO REGISTRAR EL SERVIDOR");
			return false;
		}
		ByteBuffer ret = ByteBuffer.wrap(pckt2.getData());
		if (ret.get() == OP_CODE_REGISTER_OK) {
			return true;
		}
		return false;
	}

	// Método para construir una solicitud de registro de servidor
	// OJO: No hace falta proporcionar la dirección porque se toma la misma
	// desde la que se envió el mensaje
	private byte[] buildRegistration(int protocol, int port) {
		// Devolvemos el mensaje codificado en binario según el formato
		// acordado
		ByteBuffer bb = ByteBuffer.allocate(9);
		bb.put(OP_CODE_REGISTER);
		bb.putInt(protocol);
		bb.putInt(port);
		byte[] men = bb.array();
		return men;

	}

	public void close() {
		socket.close();
	}
}
