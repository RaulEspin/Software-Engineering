package es.um.redes.nanoChat.directory.server;

import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.HashMap;


public class DirectoryThread extends Thread {

	//Tamaño máximo del paquete UDP
	private static final int PACKET_MAX_SIZE = 128;
	//Estructura para guardar las asociaciones ID_PROTOCOLO -> Dirección del servidor
	protected HashMap<Integer,InetSocketAddress> servers;
	
	private static final byte OP_CODE_REQUEST = 0;
	private static final byte OP_CODE_REGISTER = 1;
	private static final byte OP_CODE_REGISTER_OK = 2;
	private static final byte OP_CODE_RESPONSE_EMPTY = 3;
	private static final byte OP_CODE_RESPONSE = 4;
	
	//Socket de comunicación UDP
	protected DatagramSocket socket = null;
	//Probabilidad de descarte del mensaje
	protected double messageDiscardProbability;

	public DirectoryThread(String name, int directoryPort,
			double corruptionProbability)
			throws SocketException {
		super(name);
		// Anotar la direcci�n en la que escucha el servidor de Directorio
		InetSocketAddress serverAddress = new InetSocketAddress(directoryPort);
 		// Crear un socket de servidor
		socket=  new DatagramSocket(serverAddress);
		messageDiscardProbability = corruptionProbability;
		//Inicializaci�n del mapa
		servers = new HashMap<Integer,InetSocketAddress>();
	}

	public void run() {
		byte[] buf = new byte[PACKET_MAX_SIZE];

		System.out.println("Directory starting...");
		boolean running = true;
		while (running) {

				// 1) Recibir la solicitud por el socket
				DatagramPacket pckt = new DatagramPacket(buf, buf.length);
				try {
					// TODO socket.setSoTimeout(1000);
					socket.receive(pckt);
				} catch (IOException e) {
					
					e.printStackTrace();
					

				}
				
				// 2) Extraer quién es el cliente (su dirección)
				InetSocketAddress ca = (InetSocketAddress) pckt.getSocketAddress();

				// 3) Vemos si el mensaje debe ser descartado por la probabilidad de descarte

				double rand = Math.random();
				if (rand < messageDiscardProbability) {
					System.err.println("Directory DISCARDED corrupt request from... ");
					continue;
				}
				
				//	 (Solo Bolet�n 2) Devolver una respuesta id�ntica en contenido a la solicitud
				
				/*buf= pckt.getData();
				DatagramPacket pckt2 = new DatagramPacket(buf, buf.length,ca);
				try {
					socket.send(pckt2);
				} catch (IOException e) {
				
					e.printStackTrace();
				}*/
				// 4) Analizar y procesar la solicitud (llamada a processRequestFromCLient)
				//mirando el codigo de operacion
				try {
					processRequestFromClient(pckt.getData(), ca);
				} catch (IOException e) {
					//TODO 5) Tratar las excepciones que puedan producirse
					e.printStackTrace();
				}
				
		}
		socket.close();
	}

	//Método para procesar la solicitud enviada por clientAddr
	public void processRequestFromClient(byte[] data, InetSocketAddress clientAddr) throws IOException {
		// 1) Extraemos el tipo de mensaje recibido
		ByteBuffer ret = ByteBuffer.wrap(data); 
		byte opcode = ret.get();
		int protocol;
		switch(opcode){
		// 2) Procesar el caso de que sea un registro y enviar mediante sendOK
		case OP_CODE_REGISTER:
			 protocol = ret.getInt();
			
			int puerto = ret.getInt();
			InetAddress direccion = clientAddr.getAddress();
			InetSocketAddress socketAddr = new InetSocketAddress(direccion, puerto);
			
			servers.put(protocol, socketAddr);
			
			sendOK(clientAddr);
			
			break;
		// 3) Procesar el caso de que sea una consulta
		case OP_CODE_REQUEST:
			 protocol = ret.getInt();
			InetSocketAddress dirSer = servers.get(protocol);
			// 3.1) Devolver una dirección si existe un servidor (sendServerInfo)
			if ( dirSer != null){
				sendServerInfo(dirSer, clientAddr);
			}else {
				// 3.2) Devolver una notificación si no existe un servidor (sendEmpty
				sendEmpty(clientAddr);
			}	
			break;
		/*default:
			System.out.println("OP CODE NO RECONOCIDO ");
			break;*/
		}
		
		
		
	}

	//Método para enviar una respuesta vacía (no hay servidor)
	private void sendEmpty(InetSocketAddress clientAddr) throws IOException {
		// Construir respuesta
		ByteBuffer  bb = ByteBuffer.allocate(1);
		bb.put(OP_CODE_RESPONSE_EMPTY);
		byte [] men = bb.array();
		// Enviar respuesta
		DatagramPacket pckt = new DatagramPacket(men, men.length,clientAddr);
		socket.send(pckt);
	}

	//Método para enviar la dirección del servidor al cliente
	private void sendServerInfo(InetSocketAddress serverAddress, InetSocketAddress clientAddr) throws IOException {
		// Obtener la representación binaria de la dirección
		byte[] direcServer = serverAddress.getAddress().getAddress();
		int puerto = serverAddress.getPort();
		// Construir respuesta
		ByteBuffer  bb = ByteBuffer.allocate(9);
		bb.put(OP_CODE_RESPONSE);
		bb.put(direcServer);
		bb.putInt(puerto);
		byte [] men = bb.array();
		// Enviar respuesta
		DatagramPacket pckt = new DatagramPacket(men, men.length,clientAddr);
		socket.send(pckt);
	}

	//Método para enviar la confirmación del registro
	private void sendOK(InetSocketAddress clientAddr) throws IOException {
		// Construir respuesta
		ByteBuffer  bb = ByteBuffer.allocate(1);
		bb.put(OP_CODE_REGISTER_OK);
		byte [] men = bb.array();
		// Enviar respuesta
		DatagramPacket pckt = new DatagramPacket(men, men.length,clientAddr);
		socket.send(pckt);
		
	}
}
